lista = [-10, -8, 0, 1, 2, 5, -2,-4];

print(f"Maior temperatura da lista: {max(lista)}");
print(f"Menor temperatura da lista: {min(lista)}");
print(f"Média das temperaturas da lista:{sum(lista) / len(lista)}");